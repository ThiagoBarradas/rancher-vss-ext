## Rancher Upgrader

Easy upgrade, rollback and finiish upgrade in your rancher cluster.